# SRE Incident Triage Agent for Secure ML Artifact Management

Starter project for:
- Secure ML artifact management (AWS-style S3 + IAM simulation)
- SRE incident triage assistant
- FastAPI backend
- smolagents-ready structure

## Quick Start
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## API
- `GET /health`
- `POST /triage`

## Example
```json
{
  "incident_id": "inc-1001",
  "title": "Artifact missing in prod",
  "model_name": "fraud-detector",
  "environment": "prod",
  "symptoms": ["artifact missing", "deployment failed"]
}
```
