from app.core.models import IncidentRequest

def triage_incident(incident: IncidentRequest) -> dict:
    symptoms = " ".join([s.lower() for s in incident.symptoms])

    if "artifact" in symptoms or "missing" in symptoms:
        root_cause = "Possible missing model artifact in S3"
        next_steps = [
            "Check artifact path in S3",
            "Validate deployment manifest version",
            "Confirm upload pipeline completed successfully"
        ]
    elif "accessdenied" in symptoms or "403" in symptoms or "iam" in symptoms:
        root_cause = "Possible IAM / bucket permission issue"
        next_steps = [
            "Check IAM role attached to workload",
            "Validate s3:GetObject permissions",
            "Inspect bucket policy / trust relationship"
        ]
    elif "wrong version" in symptoms or "mismatch" in symptoms:
        root_cause = "Possible deployment version mismatch"
        next_steps = [
            "Compare deployed version vs approved version",
            "Inspect deployment config / image tag",
            "Verify rollback / rollout history"
        ]
    else:
        root_cause = "General model-serving operational issue"
        next_steps = [
            "Check service logs",
            "Check deployment health",
            "Inspect model server metrics"
        ]

    return {
        "incident_id": incident.incident_id,
        "severity": "high" if incident.environment == "prod" else "medium",
        "likely_root_cause": root_cause,
        "recommended_next_steps": next_steps,
        "confidence": 0.82
    }
