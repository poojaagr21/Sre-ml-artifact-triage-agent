from pydantic import BaseModel
from typing import List

class IncidentRequest(BaseModel):
    incident_id: str
    title: str
    model_name: str
    environment: str
    symptoms: List[str]
