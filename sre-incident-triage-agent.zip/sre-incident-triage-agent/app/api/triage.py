from fastapi import APIRouter
from app.core.models import IncidentRequest
from app.services.triage_service import triage_incident

router = APIRouter()

@router.post("/triage")
def triage(payload: IncidentRequest):
    return triage_incident(payload)
