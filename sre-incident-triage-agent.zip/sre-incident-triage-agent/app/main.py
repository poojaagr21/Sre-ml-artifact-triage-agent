from fastapi import FastAPI
from app.api.health import router as health_router
from app.api.triage import router as triage_router

app = FastAPI(title="SRE Incident Triage Agent")

app.include_router(health_router)
app.include_router(triage_router)
